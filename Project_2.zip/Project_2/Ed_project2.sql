--Create table structure(columns) & then import data into SQL
CREATE TABLE CREDIT_CARD_TRANSACTIONS (
	INDEX SERIAL PRIMARY KEY,
	CITY VARCHAR(100),
	DATE DATE,
	CARD_TYPE VARCHAR(50),
	EXP_TYPE VARCHAR(25),
	GENDER CHAR(10),
	AMOUNT DECIMAL(10, 2)
);
--DATA CLEANING STEP
--For Normalization, splitting data to 2 columns from 1 column 

--Step 1: Add New Columns
ALTER TABLE credit_card_transactions
ADD COLUMN city_name VARCHAR(30),
ADD COLUMN country varchar(25);
--Step 2: Extract text Using SPLIT_PART() (only String function)
UPDATE credit_card_transactions
SET
  city_name = TRIM(SPLIT_PART(city, ',', 1)),
  country = TRIM(SPLIT_PART(city, ',', 2));
--Step 3: Drop the Old Column
ALTER TABLE credit_card_transactions
DROP COLUMN city;


--Tasks:  
--1. Write a query to print top 5 cities with highest spends and their percentage contribution of total credit 
--card spends.

--METHOD 1: Used Windows function 'Sum over()'=TotalSum to find % of each city.
SELECT 
  city_name,
  SUM(amount) AS spends,
  ROUND(SUM(amount) * 100.0 / SUM(SUM(amount)) OVER (), 2) AS percentage_contribution
FROM credit_card_transactions
GROUP BY city_name
ORDER BY spends DESC
LIMIT 5;

--METHOD 2: Made Total as new table in Subquery & group that. Used 2 tables together
--to get the desired result. Used that new table & col. to get denominator. 
SELECT 
  city_name,
  SUM(amount) AS spends,
  ROUND(SUM(amount) * 100.0 / total.total_spends, 2) AS percentage_contribution
FROM credit_card_transactions,
  (SELECT SUM(amount) AS total_spends FROM credit_card_transactions) AS total
GROUP BY city_name, total.total_spends
ORDER BY spends DESC
LIMIT 5;

--2. Write a query to print highest spend month and amount spent in that month for each card type. 
--Add new columns Year & MONTH
Alter table credit_card_transactions
add column year numeric,
add column month numeric;

--Extract Y,M from date (only Date function)
UPDATE credit_card_transactions
SET 
  year = EXTRACT(YEAR FROM date)::INT,
  month = EXTRACT(MONTH FROM date)::INT;

--1st monthly spend table, then windows(rank) this table in desc, then filter rank1  
WITH monthly_spends AS (
  SELECT 
    card_type,
    TO_CHAR(date, 'YYYY-MM') AS year_month,
    SUM(amount) AS total_spend
  FROM credit_card_transactions
  GROUP BY card_type, year_month
),
ranked_spends AS (
  SELECT *,
         dense_rank() OVER (PARTITION BY card_type ORDER BY total_spend DESC) AS rn
  FROM monthly_spends
)
SELECT 
  card_type,
  year_month AS highest_spend_month,
  total_spend
FROM ranked_spends
WHERE rn = 1;

--3. Write a query to print the transaction details (all columns from the table) for each card type when it 
--reaches a cumulative of 1000000 total spends (We should have 4 rows in the o/p one for each card type).

with running_totals as 
(SELECT *, sum(amount) over (partition by card_type order by date, index) as cumulative_total
from credit_card_transactions),
filter_first_million_reached as 
(select * from running_totals where cumulative_total>=1000000)
select distinct on (card_type) * from filter_first_million_reached
order by card_type, cumulative_total;

--4. Write a query to find city which had lowest percentage spend for gold card type. 
with Gold_cities_data as (select card_type, city_name, sum(amount) as total
from credit_card_transactions
where card_type = 'Gold'
group by card_type, city_name),
Citywise_percent as (select *, round(total*100.0 /(select sum(total) from Gold_cities_data),5) as percent_spend 
from Gold_cities_data) select * from Citywise_percent order by percent_spend limit 1;

--5. Write a query to print 3 columns: city, highest_expense_type , lowest_expense_type (example format : 
--Delhi , bills, Fuel). 

WITH Grouped_Expense AS (
    SELECT 
        city_name,
        Exp_Type,
        SUM(Amount) AS total_amount
    FROM credit_card_transactions
    GROUP BY City_name, Exp_Type
),
Ranked_Expenses AS (
    SELECT 
        city_name,
        Exp_Type,
        total_amount,
        dense_RANK() OVER (PARTITION BY City_name ORDER BY total_amount DESC) AS rank_high,
        dense_RANK() OVER (PARTITION BY City_name ORDER BY total_amount ASC) AS rank_low
    FROM Grouped_Expense
),
Highest AS (
    SELECT 
        City_name,
        Exp_Type AS highest_expense_type
    FROM Ranked_Expenses
    WHERE rank_high = 1
),
Lowest AS (
    SELECT 
        City_name,
        Exp_Type AS lowest_expense_type
    FROM Ranked_Expenses
    WHERE rank_low = 1
)
SELECT 
    h.city_name,
    h.highest_expense_type,
    l.lowest_expense_type
FROM Highest h
JOIN Lowest l ON h.City_name = l.City_name
ORDER BY h.City_name;

--6. Write a query to find percentage contribution of spends by females for each expense type.

select exp_type, gender, sum(amount), round(sum(amount)*100/(select sum(amount) from credit_card_transactions
where gender = 'F'),2) as percent_cont
from credit_card_transactions
where gender = 'F'
group by exp_type, gender;

--7. Which card and expense type combination saw highest month over month growth in Jan-2014.

--METHOD 1 : Window(LAG method)
WITH monthly_totals AS (
    SELECT
        DATE_TRUNC('month', Date) AS month,
        Card_Type,
        Exp_Type,
        SUM(Amount) AS total_amount
    FROM credit_card_transactions
    GROUP BY DATE_TRUNC('month', Date), Card_Type, Exp_Type
),

with_lag AS (
    SELECT
        month,
        Card_Type,
        Exp_Type,
        total_amount,
        LAG(total_amount) OVER (PARTITION BY Card_Type, Exp_Type ORDER BY month) AS prev_month_amount
    FROM monthly_totals
),

growth_calc AS (
    SELECT
        month,
        Card_Type,
        Exp_Type,
        total_amount,
        prev_month_amount,
        CASE 
            WHEN prev_month_amount = 0 OR prev_month_amount IS NULL THEN NULL
            ELSE (total_amount - prev_month_amount) / prev_month_amount::float
        END AS growth_rate
    FROM with_lag
)

SELECT 
    Card_Type,
    Exp_Type,
    growth_rate
FROM growth_calc
WHERE month = '2014-01-01'
ORDER BY growth_rate DESC
LIMIT 1;



--METHOD 2 : 
WITH Monthly_Spend AS (
    SELECT
        Card_Type,
        Exp_Type,
        DATE_TRUNC('month', Date) AS month,
        SUM(Amount) AS total_spend
    FROM credit_card_transactions
    GROUP BY Card_Type, Exp_Type, DATE_TRUNC('month', Date)
),
Pivoted_Spend AS (
    SELECT
        Card_Type,
        Exp_Type,
        MAX(CASE WHEN month = '2013-12-01' THEN total_spend END) AS spend_dec_2013,
        MAX(CASE WHEN month = '2014-01-01' THEN total_spend END) AS spend_jan_2014
    FROM Monthly_Spend
    GROUP BY Card_Type, Exp_Type
),
Growth_Calc AS (
    SELECT
        Card_Type,
        Exp_Type,
        spend_dec_2013,
        spend_jan_2014,
        (spend_jan_2014 - spend_dec_2013) * 100.0 / spend_dec_2013
         AS percent_growth
    FROM Pivoted_Spend
)
SELECT 
    Card_Type,
    Exp_Type,
    percent_growth
FROM Growth_Calc
ORDER BY percent_growth DESC
LIMIT 1;

--8. During weekends which city has highest total spend to total no of transaction’s ratio? 

WITH Weekend_Transactions AS (
    SELECT
        City_name,
        Amount,
        DATE_PART('dow', Date) AS day_of_week
    FROM credit_card_transactions
    WHERE DATE_PART('dow', Date) IN (0, 6)  -- 0: Sunday, 6: Saturday
),
City_Spend_Ratio AS (
    SELECT
        City_name,
        SUM(Amount) AS total_spend,
        COUNT(*) AS total_transactions,
        SUM(Amount) / COUNT(*) AS spend_per_transaction
    FROM Weekend_Transactions
    GROUP BY City_name
)
SELECT 
    City_name,
    spend_per_transaction
FROM City_Spend_Ratio
ORDER BY spend_per_transaction DESC
LIMIT 1;

--9. Which city took least number of days to reach its 500th transaction after first transaction in that city? 

WITH Ranked_Transactions AS (
    SELECT
        City_name,
        Date,
        rank() OVER (PARTITION BY City_name ORDER BY Date) AS txn_rank
    FROM credit_card_transactions
),
City_Transaction_Milestones AS (
    SELECT
        City_name,
        min(CASE WHEN txn_rank = 1 THEN Date END) AS first_txn_date,
        min(CASE WHEN txn_rank = 500 THEN Date END) AS txn_500_date
    FROM Ranked_Transactions
    GROUP BY City_name
),
City_Duration AS (
    SELECT
        City_name,
        first_txn_date,
        txn_500_date,
        (txn_500_date - first_txn_date)::int AS days_taken
    FROM City_Transaction_Milestones
    WHERE txn_500_date IS NOT NULL
)
SELECT
    City_name,
    days_taken
FROM City_Duration
ORDER BY days_taken ASC
LIMIT 1;




